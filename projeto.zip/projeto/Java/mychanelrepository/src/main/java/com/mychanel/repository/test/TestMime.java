package com.mychanel.repository.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.mychanel.repository.storage.MCStorage;

public class TestMime {

	public static void main(String[] args) throws IOException  {
		MCStorage storage = new MCStorage();
		
		//G:/temp/alisson/Albuns/Soundgarden.mp3
		
		FileInputStream stream = new FileInputStream(new File("G:/temp/alisson/Albuns/Soundgarden.mp3"));
		byte[] bytes= storage.getBytes(stream); 
		
		System.out.println( "Mime Type eh " + storage.getMagicMimeType(bytes));

		//mpeg = mp3
		//mp4a = mp4
		//jpeg = jpg
		//png = png
		//avi = avi
	}

}
