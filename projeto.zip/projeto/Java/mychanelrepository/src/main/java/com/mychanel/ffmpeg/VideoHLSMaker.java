package com.mychanel.ffmpeg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.mychanel.util.UtilFunc;

public class VideoHLSMaker {

	protected String ffmpegApp;

	public VideoHLSMaker(String ffmpegApp) {
		this.ffmpegApp = ffmpegApp;
	}

	public void generateHLS(String videoFilename) throws IOException, InterruptedException {
		String cmd= ffmpegApp + " -i " + UtilFunc.resourceDir + videoFilename
				+ " -profile:v baseline -level 3.0 -start_number 0 -hls_time 10 -hls_list_size 0 -f hls " + UtilFunc.resourceDir + videoFilename + ".m3u8";
		System.out.println("Gerando HLS de " + videoFilename);
		
		ProcessBuilder processBuilder = new ProcessBuilder(ffmpegApp,"-i",UtilFunc.resourceDir + videoFilename,"-profile:v","baseline","-level","3.0","-start_number","0","-hls_time","10","-hls_list_size" , "0" , "-f", "hls" ,UtilFunc.resourceDir + videoFilename + ".m3u8");

		Process process = processBuilder.start();

		InputStream stderr = process.getErrorStream();
		InputStreamReader isr = new InputStreamReader(stderr);
		BufferedReader br = new BufferedReader(isr);
		String line;
		while ((line = br.readLine()) != null)
			;
		process.waitFor();
		System.out.println("Feito HLS!!!");

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// ffmpeg -i input.mp4 -profile:v baseline -level 3.0 -start_number 0
		// -hls_time 10 -hls_list_size 0 -f hls output.m3u8
		
		VideoHLSMaker hls = new VideoHLSMaker(UtilFunc.ffMpeg);
		try {
			System.out.println("Gerando o HLS......");
			hls.generateHLS("1212140265518069992271a84632c8539d72f6d49418791ca2.mp4");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
