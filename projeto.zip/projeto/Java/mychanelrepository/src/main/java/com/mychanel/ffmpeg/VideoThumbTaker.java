package com.mychanel.ffmpeg;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.mychanel.util.UtilFunc;

import java.io.BufferedReader;



public class VideoThumbTaker
{
  protected String ffmpegApp;

  public VideoThumbTaker(String ffmpegApp)
  {
    this.ffmpegApp = ffmpegApp;
  }

  public void getThumb(String videoFilename, String thumbFilename, int width, int height,int hour, int min, float sec)
      throws IOException, InterruptedException
  {
    ProcessBuilder processBuilder = new ProcessBuilder(ffmpegApp, "-y", "-i", videoFilename, "-vframes", "1",
        "-ss", hour + ":" + min + ":" + sec, "-f", "mjpeg", "-s", width + "*" + height, "-an", thumbFilename);

    Process process = processBuilder.start();

    InputStream stderr = process.getErrorStream();
    InputStreamReader isr = new InputStreamReader(stderr);
    BufferedReader br = new BufferedReader(isr);
    String line;
    while ((line = br.readLine()) != null);
    process.waitFor();
    
    System.out.println("Feito thumnail!!!");
    
    
  }

  public static void main(String[] args)
  {
    VideoThumbTaker videoThumbTaker = new VideoThumbTaker(UtilFunc.ffMpeg);
    try
    {
      videoThumbTaker.getThumb("C:\\ffmpeg\\1.mp4", "C:\\ffmpeg\\thumbTest2.png", 450, 350, 0, 0, 2);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}