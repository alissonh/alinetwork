package com.mychanel.services.rest;

import rx.Observable;
import rx.Subscriber;

public class TesteRXJava {

	
	
	Person p = new Person();
	
	   Observable<Person> meuObservable = Observable.create(
			      new Observable.OnSubscribe<Person>() {
			          public void call(Subscriber<? super Person> subscriber) {
			              subscriber.onNext(p);
			              subscriber.onCompleted();
			          }
			      }
			  );
	   
	   
	   Subscriber<Person> meuSubscriber = new Subscriber<Person>() {
		     
		   String ok= "ppaaa";
		   public void onNext(Person p) { System.out.println(p.getHello()); }
		   
		      
		      public void onCompleted() {
		    	  System.out.println("Completed !!  " + ok);
		    	  
		    	  
		    	  
		      }
		   
		      
		      public void onError(Throwable error) {System.out.println("Error :("); }


			
		  };
	   
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TesteRXJava teste  = new TesteRXJava();
		teste.testa();
		
		
	}
	
	public  void testa(){
		meuObservable.subscribe(meuSubscriber);
		
		

	}
	
	public void epa(String arg1 , String arg2){
		System.out.println(arg1 + arg2);
	}
	

}
