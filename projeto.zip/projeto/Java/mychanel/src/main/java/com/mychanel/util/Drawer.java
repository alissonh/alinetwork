package com.mychanel.util;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Drawer {

	public static void main(String[] args) throws IOException {

		InputStream botaoPlay = new FileInputStream(new File("F://temp//play.png"));
		InputStream imagemReceberPlay = new FileInputStream(new File("F://temp//tae.png"));

		BufferedImage imReceberPlay = ImageIO.read(imagemReceberPlay);

		BufferedImage imBotaoPlay = ImageIO.read(botaoPlay);
		Graphics2D g = imReceberPlay.createGraphics();
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
		g.drawImage(imBotaoPlay, (imReceberPlay.getWidth() - imBotaoPlay.getWidth()) / 2,
				(imReceberPlay.getHeight() - imBotaoPlay.getHeight()) / 2, null);
		g.dispose();

		display(imReceberPlay);
		ImageIO.write(imReceberPlay, "jpeg", new File("f:/temp/output.jpeg"));
	}

	public static InputStream drawPlayButton(String image) throws Exception {
		InputStream botaoPlay = new FileInputStream(new File(UtilFunc.resourceDir + "play.png"));
		InputStream imagemReceberPlay = new FileInputStream(new File(image));

		BufferedImage imReceberPlay = ImageIO.read(imagemReceberPlay);

		BufferedImage imBotaoPlay = ImageIO.read(botaoPlay);
		Graphics2D g = imReceberPlay.createGraphics();
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
		g.drawImage(imBotaoPlay, (imReceberPlay.getWidth() - imBotaoPlay.getWidth()) / 2,
				(imReceberPlay.getHeight() - imBotaoPlay.getHeight()) / 2, null);
		g.dispose();

		ImageIO.write(imReceberPlay, "jpeg", new File(UtilFunc.resourceDir + "thumb" + image));
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		ImageIO.write(imReceberPlay, "jpeg", os);
		InputStream is = new ByteArrayInputStream(os.toByteArray());
		
		//return UtilFunc.resourceDir + "thumb" + image;
		return is;
	}

	public static InputStream drawPlayButton(InputStream imagemReceberPlay) throws Exception {
		InputStream botaoPlay = new FileInputStream(new File(UtilFunc.resourceDir + "play.png"));

		BufferedImage imReceberPlay = ImageIO.read(imagemReceberPlay);

		BufferedImage imBotaoPlay = ImageIO.read(botaoPlay);
		Graphics2D g = imReceberPlay.createGraphics();
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.4f));
		g.drawImage(imBotaoPlay, (imReceberPlay.getWidth() - imBotaoPlay.getWidth()) / 2,
				(imReceberPlay.getHeight() - imBotaoPlay.getHeight()) / 2, null);
		g.dispose();

		//ImageIO.write(imReceberPlay, "jpeg", new File(UtilFunc.resourceDir + "thumb" + image));
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		ImageIO.write(imReceberPlay, "jpeg", os);
		InputStream is = new ByteArrayInputStream(os.toByteArray());
		return is;
	}

	public static void display(BufferedImage image) {
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.getContentPane().add(new JLabel(new ImageIcon(image)));
		f.pack();
		f.setVisible(true);
	}

}
