package com.mychanel.services.rest;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import rx.schedulers.Schedulers;
import org.springframework.web.context.request.async.DeferredResult;



import com.mychanel.model.Post;
import com.mychanel.repository.storage.MCStorage;

import rx.Observable;
import rx.Subscriber;

@RestController
public class FileUploadController {
	
	private final ExecutorService customObservableExecutor = Executors.newFixedThreadPool(10);
    
    @RequestMapping(value="/upload", method=RequestMethod.GET)
    public @ResponseBody String provideUploadInfo() {
        return "You can upload a file by posting to this same URL.";
    }
    
    @RequestMapping(value="/upload", method=RequestMethod.POST)
    public @ResponseBody String handleFileUpload(@RequestParam("file") MultipartFile file){
    	String name = file.getOriginalFilename() ;
    	if (!file.isEmpty()) {
            try {
                          	
            	System.out.print("Enviado arquivo " +  file.getOriginalFilename());
            	
            	byte[] bytes = file.getBytes();       
            	MCStorage storage = new MCStorage();          	
            	Post ret =storage.saveFileWithFFMpegThumb(bytes); 	
                           	
            	System.out.println("Thumbnail = " + ret.getThumbNail());
                
                return "You successfully uploaded " + name + " into " +  ret.getFileName();
                             
                
            } catch (Exception e) {
                return "You failed to upload " + name + " => " + e.getMessage();
            }
        } else {
            return "You failed to upload " + name + " because the file was empty.";
        }
    }
    
  
    
    @RequestMapping(value="/uploadasyncs", method=RequestMethod.POST)
    public @ResponseBody String handleFileUploadAsyncs(@RequestParam("file") MultipartFile file){
    	String name = file.getOriginalFilename() ;
			    
    	
    	try{
    	
		    	if (!file.isEmpty()) {
					         
					                          	
					            	System.out.print("Enviado arquivo " +  file.getOriginalFilename());
					            	
					            	
					            	byte[] bytes = file.getBytes();   
					            	Upload upload = new Upload();
					            	upload.setUser("Kaka");
					            	upload.setBytes(bytes);
					            	
					            	Observable<Upload> o = getUpload(upload);
					            	DeferredResult<Upload> deffered= new DeferredResult<>(90000);
					                o.subscribe(u -> deffered.setResult(u), e -> deffered.setErrorResult(e));
					                //return deffered;
					            	
					            	return "OK File Uploaded.Wait for a notification";
					            
					        			  
		    	  
		    	}  
   
    	}
    	catch(Exception e){
    		e.printStackTrace();
    		return null;
    	}
		
    return null;
    
    }
    
    public Observable<Upload> getUpload(Upload p) {
        return Observable.<Upload>create(s -> {           
             System.out.println("Starting RX.....");
        	 
        	s.onNext(p);            
            s.onCompleted();
            
             MCStorage storage = new MCStorage();          	
        	 Post ret =storage.saveFileWithFFMpegThumb(p.getBytes());
            System.out.println("OK FInished Task!!!!");
        }).subscribeOn(Schedulers.from(customObservableExecutor));
    }
    
    //public @ResponseBody String handleFileImageUpload(@RequestParam("user") String user,  @RequestParam("file") MultipartFile file){  
    @RequestMapping(value="/uploadimg", method=RequestMethod.POST)
    public @ResponseBody String handleFileImageUpload(@RequestParam("file") MultipartFile file){
    	String name = file.getOriginalFilename() ;
    	if (!file.isEmpty()) {
            try {
                          	
            	System.out.print("Enviado arquivo " +  file.getOriginalFilename());
            //	System.out.println("User: " + user);
            	
            	byte[] bytes = file.getBytes();       
            	MCStorage storage = new MCStorage();          	
            	Post ret =storage.saveImageUpload(bytes); 	
                           	
            	
                
                return "You successfully uploaded  image" + name + " into " +  ret.getFileName();
                             
                
            } catch (Exception e) {
                return "You failed to upload " + name + " => " + e.getMessage();
            }
        } else {
            return "You failed to upload " + name + " because the file was empty.";
        }
    }
    
    
}