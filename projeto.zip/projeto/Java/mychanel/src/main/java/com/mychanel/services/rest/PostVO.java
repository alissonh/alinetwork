package com.mychanel.services.rest;

public class PostVO {

	private String fileName;

	private String thumbNail ;
	
	private String fileType;

	public String getFileName() {
			
		return fileName!=null?fileName:"no";
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getThumbNail() {
		//Se imagem , o thumnail � a propria imagem
		if (this.fileType.equals("image/png") || this.fileType.equals("image/jpeg")){
			return this.fileName;
		}
		
		//retornar a imagem com o fone de ouvido
		//17030551511e7f671371b1fcb2488c261d070e6434730cc50c
		if (this.fileType.equals("audio/mpeg3")){
			return "17030551511e7f671371b1fcb2488c261d070e6434730cc50c";
		}
		
		return  thumbNail!=null?thumbNail:"no";
	}

	public void setThumbNail(String thumbNail) {
		this.thumbNail = thumbNail;
	}

	public String getFileType() {
		return fileType!=null?fileType:"no";
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	} 
	
	
	
}
