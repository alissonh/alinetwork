package com.mychanel.web.bean;

import com.mychanel.util.Util;

public class PostVO {

	private String fileName;

	private String thumbNail ;
	
	private String fileType;

	public String getFileName() {
		String path="";
		if(fileType.equals("image/png") || fileType.equals("image/jpeg") || fileType.equals("image/gif")  ){
			 path = Util.poster;
			 return  path +  fileName ;
		}
		//caso MP3
		else if (fileType.equals("audio/mpeg3")){
			path = Util.src;
			return  path +  fileName ;
		}
		//Caso video MP4 .
		else if (fileType.equals("video/mp4")){
			path = Util.srcHLS;
		}
		
		//N�o esquecer de fazer o lance da HLS pra apple
		
		return  path +  fileName + ".mp4";
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getThumbNail() {
		return Util.poster +  thumbNail;
	}

	public void setThumbNail(String thumbNail) {
		this.thumbNail = thumbNail;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	} 
	
	
	
}
