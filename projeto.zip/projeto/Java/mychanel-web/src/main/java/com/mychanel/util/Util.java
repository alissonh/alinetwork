package com.mychanel.util;

public class Util {

	public final static String poster = "http://localhost:8080/mychanel/image/" ;
	//Antes na era MP4 . Agora � a porra do HLS
	public final static String src = "http://localhost:8080/mychanel/stream/" ;
	
	public final static String srcHLS = "http://localhost:8080/mychanel-streamer/rest/stream?v=" ;
	
	
}
