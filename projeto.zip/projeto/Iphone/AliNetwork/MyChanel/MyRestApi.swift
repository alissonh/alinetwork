//
//  MyRestApi.swift
//  MyChanel
//
//  Created by Alisson ricardo on 01/01/18.
//  Copyright © 2018 Alisson ricardo. All rights reserved.
//

import UIKit
import Foundation
protocol tabelaDelegate{
    func refresh( mylist:[Post])
    //func refresh()
}

class MyRestApi: NSObject {
//http://mrgott.com/swift-programing/33-rest-api-in-swift-4-using-urlsession-and-jsondecode
    
    
    var delegate:tabelaDelegate?
    let  urlPoster  = "http://192.168.0.12:8080/mychanel/image/"
    let  urlThumb  = "http://192.168.0.12:8080/mychanel/thumb/"
    let  urlSrc = "http://192.168.0.12:8080/mychanel/stream/"
    let urlGetPosts = "http://192.168.0.12:8080/mychanel/service/getposts/1"
    let urlPostImg = "http://192.168.0.12:8080/mychanel/uploadimg"
    let urlPostAsync = "http://192.168.0.12:8080/mychanel/uploadasyncs"
    let urlStream="http://192.168.0.12:8000/streams/"
    
    
    public func callRest(){
       
        //Implementing URLSession
        let urlString :String = "http://localhost:8080/mychanel/service/getposts/1"
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print("deu erro ")
                print(error!.localizedDescription)
            }
           
            guard let data = data
            else {  print("deu bosta ")
            return
            
            }
            //print (" vamos imprimir :")
           // print(data)
            print (" blz impresso json:")
            
           //https://cocoacasts.com/building-a-weather-application-with-swift-3-decoding-json-data-in-swift-part-1
            let json = try! JSONSerialization.jsonObject(with: data, options: [])
           
           
            if let array1 = json as? [Any] {
                
                for object in array1 {
                    print("objeto:")
                    print(object)
                    
                    
                }
            
             }
            
            
             //print (" agora pelo JON SWIFTY:")
            // let parsedData = try JSONSerialization.jsonObject(with: data!) as! [String:Any]
            
           
           
            
            
            
                
            
            
                 /////////////////////////////////////
                
                
            
            
            
            
            }.resume()
        //End implementing URLSession
    }
    
    
    public func callRest2(){
        var listaPost=[Post]()
        var thumb :String=""
        var name :String = ""
        var ftype :String = ""
        
        //Implementing URLSession
        var urlString :String = urlGetPosts
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print("deu erro ")
                print(error!.localizedDescription)
            }
            
            guard let data = data
                
                
                else {  print("deu bosta ")
                    return
                    
            }
           // print (" vamos imprimir :")
            
         let json = try! JSON(data: data)
        
            for (key,subJson):(String, JSON) in json {
              //  print("________________Linha_________________")
                
                for (key2,subsubJson):(String, JSON) in subJson {
                   
                    
                    //=================
                       if key2=="thumbNail"{
                             // post.thumbNail=subsubJson.string!
                              //print("Campo "+key2+":")
                             // print(subsubJson.string!)
                              thumb=subsubJson.string!
                       }
                    
                       if key2=="fileType"{
                           //post.fileType=subsubJson.string!
                          // print("Campo "+key2+":")
                          // print(subsubJson.string!)
                           ftype = subsubJson.string!
                       }
                    
                       if key2=="fileName"{
                          //post.fileName=subsubJson.string!
                         // print("Campo "+key2+":")
                         // print(subsubJson.string!)
                    
                           name = subsubJson.string!
                       }
                    
                    //===================
                    
                    
                }
                //adicionar na lista
                var post=Post(fileName:name , thumbNail:thumb , fileType:ftype)
                listaPost.append(post)
                
            }
            
         /////////////////////////////////////
            
            
            for p in listaPost{
                let nome = p.fileName
                let tipo = p.fileType
               // print ("nome=" + nome + "  "  + "tipo =" + tipo)
            }
            
            
            
        }.resume()
        //End implementing URLSession
        //print("+++ TERMINOU ESSE CARALHO+++++++")
     
    }

    
    public func loadTimeLine(){
        
        var listaPost=[Post]()
        var thumb :String=""
        var name :String = ""
        var ftype :String = ""
        
        //Implementing URLSession
        var urlString :String = self.urlGetPosts
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print("deu erro ")
                print(error!.localizedDescription)
            }
            
            guard let data = data
                
                
                else {  print("deu bosta ")
                    return
                    
            }
          //  print (" vamos imprimir :")
            
            let json = try! JSON(data: data)
            
            for (key,subJson):(String, JSON) in json {
                print("________________Linha_________________")
                
                for (key2,subsubJson):(String, JSON) in subJson {
                    
                    
                    //=================
                    if key2=="thumbNail"{
                        // post.thumbNail=subsubJson.string!
                      //  print("Campo "+key2+":")
                      //  print(subsubJson.string!)
                        
                        if subsubJson==nil{
                           thumb="nada"
                        }else{
                           thumb=subsubJson.string!
                        }
                        
                    
                    }
                    
                    if key2=="fileType"{
                        //post.fileType=subsubJson.string!
                        //print("Campo "+key2+":")
                       // print(subsubJson.string!)
                        ftype = subsubJson.string!
                    }
                    
                    if key2=="fileName"{
                        //post.fileName=subsubJson.string!
                      //  print("Campo "+key2+":")
                      //  print(subsubJson.string!)
                        
                        name = subsubJson.string!
                        
                    }
                    
                    //===================
                    
                    
                }
                //adicionar na lista
                var post=Post(fileName:name , thumbNail:thumb , fileType:ftype)
                listaPost.append(post)
                
            }
            
            /////////////////////////////////////
            
            
            for p in listaPost{
                let nome = p.fileName
                let tipo = p.fileType
                //print ("nome=" + nome + "  "  + "tipo =" + tipo)
            }
            
            
            
            //Refreshamos a porra da tabela
            //Para carregar os itens logo após carregar
            self.delegate?.refresh(mylist:listaPost)
            
            }.resume()
        //End implementing URLSession
       // print("+++ TERMINOU ESSE CARALHO+++++++")
        
    }
    
    
    func generateBoundaryString() -> String
    {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    func UploadRequest(image:UIImageView)
    {
        var image = image
        let url = NSURL(string: urlPostImg)
        
        let request = NSMutableURLRequest(url: url! as URL)
        request.httpMethod = "POST"
        
        let boundary = generateBoundaryString()
        
        //define the multipart request type
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        if (image.image == nil)
        {
            return
        }
        
        let image_data = UIImagePNGRepresentation(image.image!)
        
        
        if(image_data == nil)
        {
            return
        }
        
        
        let body = NSMutableData()
        
        let fname = "test.png"
        let mimetype = "image/png"
        
        //define the data post parameter
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Disposition:form-data; name=\"test\"\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append("hi\r\n".data(using: String.Encoding.utf8)!)
        
        
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Disposition:form-data; name=\"file\"; filename=\"\(fname)\"\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append(image_data!)
        body.append("\r\n".data(using: String.Encoding.utf8)!)
        
        
        body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        
        
        
        request.httpBody = body as Data
        
        
        
        let session = URLSession.shared
        
        
        let task = session.dataTask(with: request as URLRequest) {
            (
            data, response, error) in
            
            guard let _:NSData = data as NSData?, let _:URLResponse = response, error == nil else {
                print("error")
                return
            }
            
            let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print(dataString)
            
        }
        
        task.resume()
        
        
    }
    
    func uploadMedia(videoPath:NSURL){
       
        let url = NSURL(string: self.urlPostAsync)
        
        print("postando video na magnifica url :" + self.urlPostAsync)
        
        let request = NSMutableURLRequest(url: url! as URL)
        request.httpMethod = "POST"
        
        let boundary = generateBoundaryString()
        
        //define the multipart request type
        
        var movieData: NSData?
        do {
            movieData = try NSData(contentsOf: (videoPath) as URL, options: NSData.ReadingOptions.alwaysMapped)
        } catch _ {
            movieData = nil
            print(Error.self)
            print("NIL A MERDA DO ARQUIVO ??")
            return
        }
        
         print("FAZER A POSTAGEM DA MERDA")
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        let body = NSMutableData()
        
        let fname = "test.mp4"
        let mimetype = "video/mp4"
        
        //define the data post parameter
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Disposition:form-data; name=\"test\"\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append("hi\r\n".data(using: String.Encoding.utf8)!)
        
        
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Disposition:form-data; name=\"file\"; filename=\"\(fname)\"\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
        
        //Dados do video aqui
        body.append(movieData as! Data)
        
        body.append("\r\n".data(using: String.Encoding.utf8)!)
        
        
        body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        
        
        
        request.httpBody = body as Data
        
        
        
        let session = URLSession.shared
        
         print("VAI QUE VAI A PORRA")
        let task = session.dataTask(with: request as URLRequest) {
            (
            data, response, error) in
            
            guard let _:NSData = data as NSData?, let _:URLResponse = response, error == nil else {
                print("error")
                return
            }
            
            let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print(dataString)
            
        }
        
        task.resume()

    }
    
}
