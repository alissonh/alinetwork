//
//  RestEssentials.h
//  RestEssentials
//
//  Created by Sean Kosanovich on 7/30/15.
//  Copyright © 2017 Sean Kosanovich. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RestEssentials.
FOUNDATION_EXPORT double RestEssentialsVersionNumber;

//! Project version string for RestEssentials.
FOUNDATION_EXPORT const unsigned char RestEssentialsVersionString[];
