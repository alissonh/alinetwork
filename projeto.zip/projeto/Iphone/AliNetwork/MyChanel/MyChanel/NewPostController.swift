//
//  NewPostController.swift
//  MyChanel
//
//  Created by Alisson ricardo on 20/01/18.
//  Copyright © 2018 Alisson ricardo. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class NewPostController:UIViewController,
    UIImagePickerControllerDelegate,
UINavigationControllerDelegate {

@IBOutlet weak var btNewImage: UIButton!
    
    @IBOutlet weak var btCancel: UIButton!
    
    
    @IBOutlet weak var imgPreview: UIImageView!
    
    var imgPathStr:String = ""
    var tipoArquivoSel:String=""
    var imgPathUrl:NSURL?
    var delegate:tabelaDelegate?
    
    var picker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        let picker = UIImagePickerController()
        picker.delegate = self // delegate added
       
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func addImageTapped(_ sender: Any) {
       // let imagePicker = UIImagePickerController()
        //imagePicker.delegate = self
        picker.delegate=self
        picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        picker.mediaTypes =  UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        picker.allowsEditing = false
        self.present(picker, animated: true, completion: nil)
        self.tipoArquivoSel="i"
        print("selecionando imagem")
    }
    
    @IBAction func newVideoTapped(_ sender: Any) {
        picker.delegate=self
        picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        picker.mediaTypes =  ["public.movie"]
        picker.allowsEditing = false
        self.present(picker, animated: true, completion: nil)
        self.tipoArquivoSel="v"
        print("selecionando video")

    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
      
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        
       
        
        let imageURL = info[UIImagePickerControllerReferenceURL] as! NSURL
        self.imgPathUrl=info[UIImagePickerControllerReferenceURL] as! NSURL
        let imageName = imageURL.path!
        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first! as String
       // let localPath = documentDirectory.stringByAppendingPathComponent(imageName)
         self.imgPathStr=documentDirectory+imageName
        
        
        
        if self.tipoArquivoSel=="i" {
            
            print("selecionandoo a porra da imagem einnn")
            let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
            print("selecionandou a porra da imagem einnn")
            self.imgPreview.contentMode = .scaleAspectFit //3
            self.imgPreview.image = chosenImage //4
            
            
        }
        
        //video
        if self.tipoArquivoSel=="v" {
            self.imgPathUrl=info[UIImagePickerControllerMediaURL] as! NSURL!
            self.imgPreview.image = previewImageFromVideo(url: imageURL)!
        }
        
        dismiss(animated:true, completion: nil) //5
    }
    
    func previewImageFromVideo(url:NSURL) -> UIImage? {
        let asset = AVAsset(url:url as URL)
        let imageGenerator = AVAssetImageGenerator(asset:asset)
        imageGenerator.appliesPreferredTrackTransform = true
        
        var time = asset.duration
        time.value = min(time.value,2)
        
        do {
            let imageRef = try imageGenerator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: imageRef)
        } catch {
            return nil
        }
    }
    
    @IBAction func confirmPost(_ sender: Any) {
        let rest = MyRestApi()
        let imageToBeUploaded = self.imgPreview.image
        let imageData = UIImagePNGRepresentation(imageToBeUploaded!)!
        
        NSLog("fazer post da imagem " + self.imgPathStr)
        
        if self.tipoArquivoSel=="i" {
            print("postando imagem.....")
            rest.UploadRequest(image: self.imgPreview)
        }
        
        if self.tipoArquivoSel=="v" {
            print("postando video.....")
            rest.uploadMedia(videoPath: self.imgPathUrl!)
        }
        
       
        print("feito POST!!!!!")
        dismiss(animated: true, completion: nil)
        
    }
    
    
    @IBAction func cancelPost(_ sender: Any) {
       
        dismiss(animated: true, completion: nil)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
