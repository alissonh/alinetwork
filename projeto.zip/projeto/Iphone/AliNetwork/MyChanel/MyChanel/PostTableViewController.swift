//
//  PostTableViewController.swift
//  MyChanel
//
//  Created by Alisson ricardo on 07/01/18.
//  Copyright © 2018 Alisson ricardo. All rights reserved.
//

import UIKit

import AVKit
import AVFoundation
import MediaPlayer

var playerController = AVPlayerViewController()

class PostTableViewController: UITableViewController ,tabelaDelegate{

    var listPosts=[Post]()
    var selectedPost:Post!
    
    func refresh( mylist:[Post]){
        NSLog("refreshando lista")
        self.listPosts=mylist
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
        
          NSLog("REFRESHANDO MORO!!!!tamanho da porra:" + String(self.listPosts.count))
    }
  
    func refreshPulled() {
        NSLog("fazendo o pulled caraiiii")
        loadTimeLine()
        
        
    }
    
   // override func prepareForSegue(segue: UIStoryboardSegue,
                               //   sender: AnyObject?) {
        //if(segue.identifier == "addMeal") {
           // let view = segue.destinationViewController as ViewController
           // view.delegate = self
        //}
   // }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var refreshControl = UIRefreshControl()
        
        refreshControl.addTarget(self, action: Selector(("refreshPulled")), for: UIControlEvents.valueChanged)
        
        loadTimeLine()
        
        
    }
    
    func loadTimeLine(){
        NSLog("carregandio time line")
        var restService = MyRestApi()
        restService.delegate=self
        restService.loadTimeLine()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
       // return self.listPosts.count
        return 1
        
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
         return self.listPosts.count
        //return 0
    }

   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let rest=MyRestApi()
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell", for: indexPath) as! PostTableViewCell
    
          NSLog("carregando celula")
          NSLog("thum thum carai:" + rest.urlPoster + self.listPosts[indexPath.row].thumbNail)
          NSLog("Naninha " + self.listPosts[indexPath.row].fileType)
        
        cell.lnlPerson.text = "Naninha " + self.listPosts[indexPath.row].fileType
        var urlImage:String=rest.urlPoster + self.listPosts[indexPath.row].thumbNail
        
        if self.listPosts[indexPath.row].fileType=="video/mp4"{
            print("eh video , chamando thumnail")
            urlImage=rest.urlThumb + self.listPosts[indexPath.row].thumbNail
        }
        
        if let url = URL(string: urlImage) {
             cell.imgPhoto.contentMode = .scaleAspectFit
             cell.loadImage(url: url)
        }
        
       
        return cell
    }
    
    
    @IBAction func reloadTimeLineClick(_ sender: Any) {
         loadTimeLine()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //https://www.youtube.com/watch?v=A6Wl8ySrOZI
        //chamar segue no video acima
        let rest=MyRestApi()
        self.selectedPost=self.listPosts[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell", for: indexPath) as! PostTableViewCell
        
        //cell.target(forAction: getAction, withSender: )
        
          print("clicado !!!")
          print("selecionado:" + self.selectedPost.fileName + " do tipo + " + self.selectedPost.fileType)
        
        if self.selectedPost.fileType=="video/mp4"{
            //chamar video
            let urls = rest.urlStream + self.selectedPost.fileName + ".mp4.m3u8"
            print("chamando video " + urls)
            //let url = NSURL(fileURLWithPath: urls)
             let url = URL(string: urls)
           
            
            
            
            let player = AVPlayer(url: url!)
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            self.present(playerViewController, animated: true)
            {
                playerViewController.player!.play()
            }
        
        
        }

        
        
    }
    
    func getAction(sender:UITableViewCell)->Void {
        if(sender.tag == 0) {
            print("it worked")
        }
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
