//
//  RestApi.swift
//  MyChanel
//
//  Created by Alisson ricardo on 01/01/18.
//  Copyright © 2018 Alisson ricardo. All rights reserved.
//

import UIKit

class RestApi: NSObject {

}
