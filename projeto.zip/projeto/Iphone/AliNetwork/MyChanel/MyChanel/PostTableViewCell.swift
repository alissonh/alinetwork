//
//  PostTableViewCell.swift
//  MyChanel
//
//  Created by Alisson ricardo on 07/01/18.
//  Copyright © 2018 Alisson ricardo. All rights reserved.
//

import UIKit

class PostTableViewCell: UITableViewCell {

    
    @IBOutlet weak var lnlPerson: UILabel!
    
    
    
    @IBOutlet weak var imgPhoto: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    func loadImage(url: URL) {
        print("Download Image thum thumbs Started")
        getDataFromUrl(url: url) { data, response, error in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download thum thumbs Finished")
            DispatchQueue.main.async() {
                self.imgPhoto.image = UIImage(data: data)
            }
        }
    }
    
    
    

}
