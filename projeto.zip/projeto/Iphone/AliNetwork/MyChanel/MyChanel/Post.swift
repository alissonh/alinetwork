//
//  Post.swift
//  MyChanel
//
//  Created by Alisson ricardo on 06/01/18.
//  Copyright © 2018 Alisson ricardo. All rights reserved.
//

import UIKit

class Post {

    var fileName:String=""
    var thumbNail:String=""
    var fileType:String=""
    
    init(fileName:String , thumbNail:String , fileType:String){
        self.fileName=fileName
        self.fileType=fileType
        self.thumbNail=thumbNail
    }
    
    
    
}
