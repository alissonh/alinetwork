var HLSServer = require('hls-server')
var http = require('http')
 
var server = http.createServer()
var hls = new HLSServer(server, {
  path: '/streams',     // Base URI to output HLS streams
  dir: 'F:/temp/'  // Directory that input files are stored
})
server.listen(8000);
console.log('Rodando...');
//acessar por exemplo
//http://localhost:8000/streams/1861188502b2559b4bcf0fefc5577b174e4573d1688ac89845.m3u8
//http://localhost:8000/streams/v.m3u8
