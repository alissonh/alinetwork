//nao esquecer
//npm i gridfs-stream
//npm i mongoose
//npm i express

const fs = require('fs');
 const express = require('express');
 const app = express();
 app.get('/', (req, res) => {
   fs.readFile('./index.html', (err, html) => res.end(html));
 });
 app.get('/movies/:movieName', (req, res) => {
   const { movieName } = req.params;
   console.log('video passado:' + movieName);
    mongo = require("mongodb"),
    Grid = require("gridfs-stream"),
    
    buffer = "";

	//https://www.npmjs.com/package/gridfs-stream
	
		mongo.MongoClient.connect("mongodb://127.0.0.1/", function (err, db) {
			"use strict";
			//var db = new mongo.Db('mychanel', new mongo.Server("127.0.0.1", 27017));
           console.log("conectando...");           
		  var gridfs = Grid(db, mongo);
           console.log("conectado tentando ler");           
		   
				// read file, buffering data as we go
				var readStream = gridfs.createReadStream({ filename: "579949041063982da67277964e4cde855ea0865bc76853329" }); //usar o  movieName  aqui
                           console.log("lido tudo...");            
				
				readStream.on("data", function (chunk) {
					buffer += chunk;
				});

				// dump contents to console when complete
				readStream.on("end", function () {
					console.log("CONTEUD0O DO ARQUIVO:\n\n", buffer);
				});
				
				 res.set('Content-Type', 'video/mp4');
				// res.set('Content-Disposition', 'attachment; filename="' + file.filename + '"');
				 res.status(206);
				 //tem que dar um readStream.pipe(res); 
				 readStream.on('open', () => readStream.pipe(res));
				 readStream.on('error', (streamErr) => res.end(streamErr));

			
		}); //fecha a porra do conect
		   
 
 }); //fecha o expresss
 app.listen(3000, () => console.log('AliFlix Server!'));